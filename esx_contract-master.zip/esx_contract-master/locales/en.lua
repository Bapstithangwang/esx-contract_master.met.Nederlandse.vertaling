Locales ['en'] = {
  ['writingcontract'] = 'Contract for the following license plate: %s',
  ['soldvehicle'] = 'You sold the vehicle with the registration number ~r~%s~s~',
  ['boughtvehicle'] = 'You bought the vehicle with the registration number ~g~%s~s~',
  ['notyourcar'] = 'This is not your vehicle',
  ['nonearby'] = 'No vehicle nearby',
  ['nonearbybuyer'] = 'No buyer nearby',
}
