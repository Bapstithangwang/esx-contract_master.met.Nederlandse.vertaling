Locales ['en'] = {
  ['writingcontract'] = '%s plakası için kontrat yazılıyor.',
  ['soldvehicle'] = 'Aracı sicil numarasıyla sattınız. ~r~%s~s~',
  ['boughtvehicle'] = 'Aracı sicil numarasıyla satın aldınız. ~g~%s~s~',
  ['notyourcar'] = 'Bu araç senin değil!',
  ['nonearby'] = 'Yakında araç bulunamadı.',
  ['nonearbybuyer'] = 'Yakında alıcı bulunamadı.',
}
