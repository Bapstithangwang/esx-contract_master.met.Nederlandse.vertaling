Locales ['en'] = {
    ['writingcontract'] = 'Het contract voor deze nummerplaat: %s',
    ['soldvehicle'] = 'Je hebt het voertuig verkocht met dit registratie nummer ~r~%s~s~',
    ['boughtvehicle'] = 'Je hebt het voertuig gekocht met dit registratie nummer ~g~%s~s~',
    ['notyourcar'] = 'Vreemd, dit is niet jouw auto',
    ['nonearby'] = 'Er is geen voertuig in de buurt.',
    ['nonearbybuyer'] = 'Er is niemand dicht bij die jouw voertuig wilt kopen',
  }
  