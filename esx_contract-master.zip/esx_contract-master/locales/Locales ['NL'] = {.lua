Locales ['en'] = {
    ['writingcontract'] = 'Het contract voor deze nummerplaat: %s',
    ['soldvehicle'] = 'Je hebt het voertuig verkocht met dit kenteken ~r~%s~s~',
    ['boughtvehicle'] = 'Je hebt het voertuig gekocht met dit kenteken ~g~%s~s~',
    ['notyourcar'] = 'Vreemd, deze auto is niet van jou',
    ['nonearby'] = 'Er is geen voertuig in de buurt.',
    ['nonearbybuyer'] = 'Er is niemand dicht bij die jouw voertuig wilt kopen',
  }
  