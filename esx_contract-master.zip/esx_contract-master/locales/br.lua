Locales ['br'] = {
  ['writingcontract'] = 'Contrato para a seguinte placa de veículo: %s',
  ['soldvehicle'] = 'Você vendeu o veículo com o número de registro ~r~%s~s~',
  ['boughtvehicle'] = 'Você comprou o veículo com o número de registro ~g~%s~s~',
  ['notyourcar'] = 'Este veículo não é seu',
  ['nonearby'] = 'Nenhum veículo nas proximidades',
  ['nonearbybuyer'] = 'Nenhum comprador nas proximidades',
}
