Config = {}

Config.Locale = 'de'