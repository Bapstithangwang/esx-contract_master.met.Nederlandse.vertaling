INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES 
('contract', 'Kaufvertrag', '5', '0', '1');