# esx_contract
With this script you can sell a vehicle to another person. You just need a contract in your inventory.
There is no moneytransaction included.
It´s just a simple script to change the owner of a vehicle
